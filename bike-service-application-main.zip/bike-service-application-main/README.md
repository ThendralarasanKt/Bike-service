# bike-service-application

Run The Program

Run The Below Commands to Start

**In Backend Terminal**
   ```cd bike-service-application-main/backend```
   ```npm start```

**In Frontend Terminal**
    ```cd bike-service-application-main/frontend```
    ```npm run dev```


**Open the Link**   ```link http://localhost:5173/ ```
