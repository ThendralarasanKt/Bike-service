import FirstStep from './components/Firststep';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register'; 
import { BrowserRouter, Routes, Route } from "react-router-dom";
import States from './components/States';

export default function App() {
  return (
    <div >
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Register />} /> 
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/home" element={<Home />} />
          <Route path="/firststep" element={<FirstStep />} />
          <Route path="/states" element={<States />} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}
