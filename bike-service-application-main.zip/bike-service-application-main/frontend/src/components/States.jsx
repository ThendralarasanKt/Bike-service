import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';


const products = [
  { code: '001', name: 'Product 1', category: 'Category A', quantity: 10 },
  { code: '002', name: 'Product 2', category: 'Category B', quantity: 15 },
  { code: '003', name: 'Product 3', category: 'Category C', quantity: 20 },
  
];

export default function States() {
  return (
    <div className="container mt-5">
      <h2>States</h2>
      <DataTable value={products} className="p-datatable" tableStyle={{ minWidth: '50rem' }}>
        <Column field="code" header="Code"></Column>
        <Column field="name" header="Name"></Column>
        <Column field="category" header="Category"></Column>
        <Column field="quantity" header="Quantity"></Column>
      </DataTable>
      <Link to="/home" className="btn btn-primary mt-3">Back to Home</Link>
    </div>
  );
}
