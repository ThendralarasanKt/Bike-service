import { Fragment } from 'react'
import { Disclosure, Menu, Transition } from '@headlessui/react'
import { Bars3Icon, BellIcon, XMarkIcon } from '@heroicons/react/24/outline'

const navigation = [
  { name: 'Dashboard', href: '#', current: true },
  { name: 'Service Registration', href: '/Firststep', current: false }, 
  { name: 'Service Table', href: '/States', current: false },
]

function classNames(...classes) {
  return classes.filter(Boolean).join(' ')
}

export default function NavBar() {
  return (
    <Disclosure as="nav" className="bg-gray-800">
      {({ open }) => (
        <>
          <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
            <div className="relative flex h-16 items-center justify-between">
              <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
                
                <Disclosure.Button className="relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                  <span className="absolute -inset-0.5" />
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
              <div className="flex flex-1 items-center justify-center sm:items-stretch sm:justify-start">
                <div className="flex flex-shrink-0 items-center">
                  <img
                    className="h-12 w-auto rounded-full"
                    src="https://img.freepik.com/free-vector/hand-drawn-vintage-motorcycle-logo_23-2149432258.jpg?t=st=1715702657~exp=1715706257~hmac=52b12d6c5038b35c28a57ebc7835e497a089c78ef755764679726bf09a70b8cf&w=826"
                    alt="Your Company"
                  />
                </div>
                <div className="hidden sm:ml-6 sm:block">
                  <div className="flex space-x-4">
                    {navigation.map((item) => (
                      <a
                        key={item.name}
                        href={item.href}
                        className={classNames(
                          item.current ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white',
                          'rounded-md px-3 py-2 text-sm font-medium'
                        )}
                        aria-current={item.current ? 'page' : undefined}
                      >
                        {item.name}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
                <button
                  type="button"
                  className="relative rounded-full bg-gray-800 p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
                >
                  <span className="absolute -inset-1.5" />
                  <span className="sr-only">View notifications</span>
                  <BellIcon className="h-6 w-6" aria-hidden="true" />
                </button>

                {/* Profile dropdown */}
                <Menu as="div" className="relative ml-3">
                  <div>
                    <Menu.Button className="relative flex rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                      <span className="absolute -inset-1.5" />
                      <span className="sr-only">Open user menu</span>
                      <img
                        className="h-8 w-8 rounded-full"
                        src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExIVFhUXFRUVFxgXFRUVGBUVFRUWFxUVFhYYHSggGB0lGxcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0lHx8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAADBAIFAAEGB//EAEcQAAEDAQUFBAYIBQEGBwAAAAEAAhEDBBIhMUEFUWFxgQYTkaEiMrHB0fAHFCNCcrLh8VJigpKiMyRjc4PC0hUWNDVTo7T/xAAaAQACAwEBAAAAAAAAAAAAAAACAwABBAUG/8QALxEAAgIBAwIFAgYCAwAAAAAAAAECEQMSITEEQRMiMlFhgfAzNJGhwfGx0SNCcf/aAAwDAQACEQMRAD8AvLLUVnTaYlRs9mDTEKwAXnWz0FEKNLUolRHpCFt8KnwDq3AMCVtQR6tSEnWqSolYRXVAoNamjRlbFNMRCNAK8sTMFSBsFO2eoZCNASOipWVMupNAxKQs9pMRKrds7WuiN3z4rRBLsZfDnKVWNW3agp+r63ziuR2vtdzpvPceuiUtdvJmFTV3k7+q1Y4KJoUIxC17XpPzzSz6u9LGoRPz5Jc1TOc+SeA2WHfjXh4pqlanARew8Fz7qp368/2RKdrLTj+qsB0dLRr3/ROB0j3oNqYWGCPk5KtpbQgtc3FwIOmm9WrtoMe1jXCHAAXpkHTGfYsuTp4ydoOMqK2pUQatVWFusQiWkF24e5UtQpDxOJbkS71SbVSLisZWhMURdj9TJLuKkbQCFB71aRTZoFF71LgodV6YmLY33ixIX1iIE9jY+U5ScFXNciiquEdZqxqrUQjWQDUQ3PVoqqGb8qFRkKNMqRqIwCEoZqhFfEJJzVaZAr6gUqdZJ1Cmdk0O8qNZpmfwjE/DqiRTpK2dA2mWUr5GLhIHPJcdt+plJkYnheO/fkV2+134EDIHDgI0XD7Zpb9MYGO8ydNVrx7MHDbg5PuUloeYAy5D4pOoSdD5BStLwcY6E/ApMsx9w+K2xQMpEajuHzzSb3DHJOua1umPik6rwmIVIHfHFZ3kj4qBdxPSVINPUqC7J0mHMH51RadYwlHkgwMtOKmRhyiVCrLGw2mHGcQQdfneUS3Mn0hyPOBiqmjUV7Y3B7S0D7s8iMR7wgyK0FF3sVD6ZQCxWl2UvWpQkJkYi4wtd4VKoEez2bCSrAIh2CDVKYrs3JQq0U2ahYslbRAnsDioOctuKVfVhcA66CmqtB6VdUUDWRxRTHzVhDqWlJiugVqqYkCWX1pLPt4lV1S0Kvq1TKNQKL51olW/ZETWdwpP8TAC5Kz1MM10nYe0g2hzf92fItRKNOxeT0s6S2VPScDnAIHA/Oa47atQOcW3h6UzGUiTmVedoLXcvTHpANw4DHzXHVyZnKMY1x+QteODe4cPLFCNopjjHFKBoCe2raBI1N0AwBAholI0m/ZzvJPnC1x43AnV7A7TAGirahLjAyCbFdsQcxmlqttaMkSET3Mp2fefciGAq91sJWr56fOasC0iypBriJMDQ+9CtlnLHY4fOCRfUOaeo1u9ZDs25cioCDbvVvsmrBA3kT0yCpXyE9Zq3zuUasuI5afQc4bifalKtWUbbLvSaR95rT1iD7FXFyz6CSlToMGyZTT4upOzOxRK1XFXQNkatTBKuMor8UJyugWyC2o3lihR69VckK70es9JVwuEkdawb6qhfQXlQ7xOiirDXkGs9ae9J2h5ToxBsk+qkK9Q6Kb3paU1RAkwjaxAzXTdgXHvqjt1F3QlzY9i5Zdp9H9mJp2hwzLWtHg5x9gUfAF+4h2kttUNaTEhl2ZzI+91XEVbe8Omf8k/2kNatUZQZelzrobMGd3BUNo2WGvuuiWzIxwdEZ6iVrhUVRM0pX5ewd1tcTiD7VeWQOdRa7ADLIkmMzwXN92Mt3BdrZKBp2aiHatLjPE4DwhNW9A4k23Zye02kH3hV1SdVabRbLzzSNRhBwTGjNL1AIdEB0cvnFbZRcJ9I8Dv6JijTJKc7nDQdJS3HctRvcRovdkc0egXNMjrimBQaVq4BhhzjIIyUxz6sakOaOfBDqWdzCQdOoPVZQqXcEx3sqBbBLa2aLH6tcWcYMH2+1V91at1oMBkwJBjj8hAba3F1xzYw9E6kDMHx8kGkpq9wwEKLzisc+EF9VCLbCGohuegl6y8oDZOViisVUSz1So5Bc5HqNSziuIkdZitYpdzkeuUtUOCfFAkTUQarwVFwQynpUCyLgo92pYqLqiKwDC2F3/0dsu2es93ql4aOd04eJC88dUXpPZR07LIGB7x4J5n4QqfAMt9vcrLFstotFS0PLS8XzSYPRDC7BzjJOnRcdtOlLyXGZJwGPn711tlJkgb/SJzcYzJ0BmfLmpabM0XiYwIJwGow5nBOxumaZY7RR7A7Mmq8FwugnLcMyTyGKhtval6o5rPUabreTcB7ETaW2aoY9lBxY4gYjMNEyJ0k3Z5Llfq9a4alSDJwI+9vPitEbu2Im9C0xDVqwvEOyBQnPAIMy0+RSVSzE4umNynTp5NAwG84p1mTVuP92M1NugKEx13XD2Jqk8Ec/kIbGqK7G72RUXVBnr86rR3a+7VBq8FCPYn3mi3fgpVqOXKAWRtTScuPXDRL067obeGRBB1E4HxBKae7Lf8wlg0gG9nM79ZwQstAalaVEFCfUkysDkJnYZjlKUtfRmOUIEvrFG8Fioh6m+sl3vRKgS1RcVLY6zIVCl3oxQ06BTFiFhaivCjgtCFyAvGCSqqxcIS1QDFMoXZV1aq776OrXes1emZMPa6J0c26fyrzy1ROa6P6NbT/tL6U4VKLh1aQR5SqyR8jKhLzqzu2WQUxiMS28fxDEDlBPguE29tbEgamI37vNdr2ttvd0nkGCIAjOCI9y822TZTVqXzi1vLPRXhqnJmuUnS92W+yLAQ0uIkkSTu1upDtI6SBjAwAjx6zK60Q1gMhrACXHAAY7/nI5rjNobSovcYJIBz0cmY5OUrYvKko1Ygyzy2Y0S/ccR8E9bNpANhogakxJ5DRI/+INJxC0JmNqPubLMIP7lDZULTGaMXAjOUCp+6hLrgZLoxwO8pd1RRDpGOnzKi04HqrRcpWT1U5xQBUClTVAWSqVYOO/3Le0B9mH7xdjiTj5SpGgHmDI5e3iq62scxxpEyGnDSZGBVNkk6QALJWyFkIRJoKV5ahRVEJXlijKxQuz2KsElUCfqBLVaa4yOsJPCgSi1cEu9ydFAtmnFBqOWOKg8LRFCpM24zgk64Kk5xlBtLytEUKkyrtzCrn6N6oFsBJxuPji4lojwnwVTaDKd7I+jbKDv960eJj3qZI+VoXCVSTO87fVAKDyfvFrZnmT7FylktDaFnYBi4kvdoROWO6IxXSfSED3VOngL9Tflp71x1roPr1u5pwMYkmA0YCTGiT06uG5vm63Qvt7arqxZQpBxaBiBJL3mJMDQZKuq7HtAxLQ3mcV3dGnRsFB7Kbr9b0b9SIJJBJjUNyAHCdVRbW286s4uuhoO7w1WiD7JbCJ4+83uc0/ZdaAXRB4k6KH/hz9D5K2p21x+8eWOA4LKVsOXHx3exNE6IlObLVbjHgt0asmHAzxwVm+1HFCdWLp18FewGnfYA0mZ4ojgDjvUbmEeHgsa7DkqLQNqniFkwceaiQoChmm73IG2my5r94jq39IRKYkcVO1MlnI/p8FT4LkrRUFbWPCwlCINFRWytwqIRhYtwtqEPZHtUXMEI1VyXqOwXHidgUtFNVlZqsqplL1GrRBC2xABbrDBGc1QurRFCWV9VhzS0zmrdzVXV6WOAToipCFrbCjZKtypTfo17HHk1wPuTNSxuSlrZAI4JjViba3O97d1A5tA5w4knecPguY2M37Q1OJHOGucfcr7br+8sdCqPvNa/+5okcwcOiqLOwiiXZC693V0sb+VyyYPw6+h12lqT7cju0aGN4xD6bYk4lwg5rmu7MuMZcN66XE3bwi5UjMDABsKndi6oMIiREZ3v1T8T2E5Y27KmmxwceOHt3KRBD05Ro+kRugkTjqgv/wBQADQ+7FNMtUhTvAS4x+y1ZnY8xCymyS/l71Cm0wd7T4Zn4KwU97JVKeg0xHJQac04XwGkaY5Tgc0C0QSSNVCMXDpPT4/FT9uaG3Pop2gHyUBJ03pumAQW7wR5YJCzCU9ZXQ4OGmPhkrrYNMqqgQ2tXa2euzaBq06oayqw+i5oDbwcCGnHHA6TqFxtVpY5zHCHNJa4biDBCzwnqtNU0JnDTw7RF7VgWOKi1MAJQsUryxQs9efWSlR6i5yg44LkpUdS7BvcgvctvchynwAZouQ3FScQgOqQtKQpsg6qVlOohuqBAfWTYoTJh320ZKl2pUvHBMPfBW9l2bvKwn1GkOdOWGTTzI8JRuoxti/U6R1HZthr7PbSMksfUYPwlwqDoL5HRGr0gGsYIi+QMPWFFg6gEh2qr+yXaS/bK9O9LLl6nhmaRN8/1Xp/pR6lcimHfeFKtJwHpmo2Y6QFhWrW7+7OthacF+hGrTHoT95znGCN83oOcta2OapG1gH1Dn6IA11A88E3a64uWeD93E/0XZ8wqR1WHgg7x7x7Fqxiss+A9OsA5+/5zS/fQ8df3Srnm+d5w8VG1PN9uW7DemmRyHmEAuA1E+33oVnxMbxrlgcFE1MQeBHmMFEP9IEYYn9AoRvckXESJ1nooU3yBhhlmtl/pHl7EOnl1PtVgshUOPzvUKz9FGs/FRoiXCVQI5Z2wEacJURhvWrU70Y4JiCfBDs5tFrLRULjAc3Xe0/qV1fa3YjK1MWmztl3oSB95j6d4HmIK86sL4rD8UeOHvXqWwbX/s2ObTQbyuksHsC5vUNwmpILAlKLizzkZKIK623dnXV61V1AAEQ4syBJkmNx+K5itZ3Mdde0tMAwdxyPFaMeSM+ORU4OPIKFimsRWAemOKjKO6mg1cFzUrOiL1ktUKZqGUhaFoggGbcUAklbaUUNT4oVJilYJcJi14KvNQpqQmRC1lTsFncaVWpBuAsbqAXFtQwBk6Lp5dVedjdhttlcNqh3dNBc4jCYIAbe5uGS7L6RrIylYi2mxrWMqU2taIAA7urkOqydX1KT8JcsPBHzameL9lLZ3dsou0mDxBGIXeguNGpiHG/WadBPoOwHSZXmWz3RWp8wvQLUcLwwkCf16FaMkeB/SSehr5ELU/7OlhkI/tMRwyVdXeLw5ppzXXThIzGvMcMlWl4/dFH2AytkrTi8FRtmbcMvasqVQYMjRbrWlpHgUQphnZAqD/WB64oH1jAADxhQLjqoRsI52J3nQZITqhyW2sJyU2UFZKYFrCUzSp9FNlMIrG71YSiSDR16odpbIhFw3ceaA/oiLlwUVQXak9fArv8AYlrJZBPrVKX5pXFbRpZO8V0WxrQAKJHAn+kHFYuqXAOHZs7nszbGtfaHnfAP4abfeVw3aCqH2hwIBugNw/laJx5kq92RaIoP/mqP8C84/wBoC436yHPc/eSf7jPvSOnj55MZll5UgncM4+Kxb71ixa7M56fUQKrJTFRAqVFiijoMRqNSdZmKsaiUqsWiKFyE6jcEsXkJ+ozBTsex6lTEi4z+I6/hGvsTXOMFcmKpydIpRee4NaC5xyA1XSWDs3Tpw6u4Odn3YOA/EdeQUrY1lnAZSwJ9Y5uPEn3BVla3E4TnE6krDl6qeTbHsv3NEOnjHee7Ou7N24G1ljQA0UTAAAAu1GHIcJTX0oNH1YjMd613/wBVQBcx2aqBtqokH12VmnmKZIHkFedvbUHUajYBJFFw/l9JwvDoY6rmz2yRDlFuV/B4XYB9qxeg2d4cyDuhef2QRUb1C7awVhAnx4hele6MnSOm0Cm4RuOnRAtVmDsY+fenLbRzIy098JOnU0Mgoa7o0S9mJ/UkM2A5T5KzeIUnVAVdinCJWNsMan55KX1cZYQrItBQ68DJWTw0hRlPCFG7jA0R4nL4LQpxjroiBoEGalFa4afotVCFumzDT3oikDqjVBZiUSvic/NLF5UFye4K3s9Eo+yqt2leOQvD9vFQrNwK1s5l+hUYMw6fIfBZ+o4T+SoeovtmvPdBrnXRdIncSLs+JXO17OWOcxw9IGP2VqwuF1rsBgMiN5PsCsqmzWVoJeLwAEgwY0mc1njJRd9mG1qRytwrF1P/AJZP/wAnk34rEXjQA8OR2NQpd6LVKe2RsKtaPVF1mr3DDoNUtVFWzXKRTnNMUbI6oYaOZOAHM6Ky7eUqVioUWsBJfUcHOOLiQwkchOip3bVe6kxogC63CI+6MSly6io3BExxU+5cWKwUKZlxFR4/tbyGvMqo2ztg3iAZ4orarmU8czM79YHBUlegSZJxOmJJO4AYnosVvJLVN2aklFVEVrWkmT5lKtpmRP69Auw2T2UqPAdUApt3uAvAfhmG9ceCctlaw2ISSC7VzjJPXP8AtEIvHitoq2A1fLKzs1Zu4ItFQEOvNa0ESW0yRfcRoSMIzhL2m1F4cHT6NB4kxi+k9sAg4iYKrbb2vfaj3NmoPqE4EN9FokYy7Jo4khJ7Pp2yrVqUHXWvaajnOLrzbwBcYa0i+TvyQywTfnnt/wC9illhdROLcYrR/M78y6Oz1Mguf2jZiy1PaXXjemSIJvAOmNM1dWUkiF34+lHOx7SaL2gQ4HLKISNtpBpwCnY3luictbA5pO4cc5URs9SKylW0W3AFBqSFthnX55q6FKXubLOOXNTugLHN81rRQuyJwy+eamMuPT5C0KYzW5UKYM3TotuIAjDyW2MiSl67tUaAbpEK7woBCcZUb0KCXI3WqYFEslmLKRcHOa5244b5LSMcMOqnYrD3hvHBgxM4A/p7ck5aTfN1uQ8h8T85LLnyK9K+oUIvkRFjL2guqVL+YLboEaS39VBjK7D6NYE7nN+Eq0pmMdMvxHhwRLNQvGTjikqVL4Lrcr+/tm+n/l/2rFdej8ysQ64+wWl+56RsgUR3Qe1pdUL3EuxhrDDQJyxkrrq1vAbDBI8Gjr8F5rsK1OtFoBwNGiLrTd9d0y5/AEzA3Qup2zartGpWdeLKTDULW+s67jdauTmyNzpPk1PFGVOXY4/6X6zu7s8nOpUOGWFOFztjtZN0gyQAA0CSYGcCSVOwUK20Kv1u0ERH2NISWMpnLDj5+S6pzqVkYLrJcW3gA0NvSYaI0k5T/Cdy0PKscViW8kXji23PhAdk7FtFYX6h7tgxkkT1nADx5Kwdtiw2IRSBr1YzYC89XaDwCUrVqtpBD3eiBN0GGiM8Bn1lLs2a0YQN2Q5ZBZXNN+b9ENabENqbdt9q1bZ2aAC+7w9QHqVUt7PMP2tQuqvnE1XF/wDjg3yXQvaHY3ZuHLLDGfeeiaDG9CPbmmxzaF5VX378gPGnsyo2bTaBEYt0GAA4AYD9ESu7uLTStGjovOGpboeYlM06Pdk8N5zHz7Fu+0sc1zb1I5jWmUE5u9XYJR2ope3vZuajbTQF4FuQxvMzERm5snDVpEZY8zZn5Lu+8q0AQD3lEjDCS0aXm59Qq7adGzVftGi4TjhJExjeIy/qA5rd0fWuCUJ7rs1/KE5Ont2uStsdTemKtTqPmEmaDgJEFpyIgT7j0JURUIwII4HBdSMoz3iwFqjszVoeDz5JN+8I9pqDQJIPnUJqFTYzTq5JlrgUi0SMESm9TSUpDIGBz3obngRp8FNonkMckjV5FUE3SsJVrg6pYvWBn7a+Ga09zRrJ3DGOeg6lU8kUKdshElGpU2g+lj/KM43mchz81GlSe/IQN8x5/DxTNKg0ZC8fBoWfJnvZEUA5c6oP4WDEaAcv4jxPRTLQMsGebjr+6010/wA35f1RadM5nqTgsw2yDGXjGugGTQnbgb6MYan5+fFEs5aGufnoMImN3mtWf0jGgzQuRdA+8HHyWJ7umbj4D4LEHiIvSzrey9lbQpAlwyxOkcFZG2CuTTYCWOBY52TbrhBz9bp4rzbZfa2m14ZbKDqeQJYC9mG+mcY4glei7M2jTrNvUXtewfeaQQOYzbyIXHz9PlxvVJfU3QlCapHOdkLOaD30H4Gi40T0xpu6sLT4o22CKlqux6tRzOlKmyPB76nipdrdo07LaqVrcfRqtuVQIl3dy6m8f5N5OG5VPZi3msadciO8rWmoZxgGo34J6jJqWbs1++9/4AUltDv/AEdDsyywIOoPXEDop1GwXCTnJ64x5otmpj0X6AunjJMDhjHgla7i2oQ7EbxumW+2OgWaL3HMG2iRMGBnz3+Q8ih2ijcwdl934I1SqB7t43FDtFbvKcbhhG/TljHQpqsBga32tOYxG75+cEs+mRiPRPL2zgVlktjYJgwRj1z9g81PvXRDKZPEyR5mPNN3ToHkS+sXScbp4YsJ5aIFdjX+k+nyqUonqBn5o1pqOGFSn1A94SlNrSfRqXTOuHif3R6VyDb4B/UjevU6zXOnI/ZOP4owPIhEeyoMKlnMZzcB0zmkQI/pOiaqWKo4YtD/AAx5ZE9AUkWupfdrU53XgP8AKB5KKTfDT+/j/RfAtDPv0j4hv5msULXs2g+k6pTlpBILXubPq3mkQ4ggp+lb36VcP5qYd5gKx2baXOqAODXAtJvQRm10YTGat9TlhvfHy/5J4cZf0cJRqxrgi98EnSkXhue4dJWy9elTtWcptl1ZXtI1iMYBmNVX1bO84tgbyYmeEyrLZTgQ4R9yPFzQl7dZ7vE3og5Ccclgz5P+TSadNxTEH0dH1Z4DHyGHkpsptbiGdXe4IooneByARGWcZgOd1geKW5AqINsnP0uGQ8EQ0v4jA3fP6pyhYnkSfRHD58wmqezQOPE5+KW8iXcPSxKg45MHX4KwoNqAZ+z4IzGtB3DwW22lgwLh4pbnfCCUaF7SKhER7PjyWqDCymScXGeOenuTTrQD6uJyw471G+JxyAj4qauxEtypmpx8CsVv3zOHgsReJ8E0/JW9sv8ATbzPuQvon/8Acf8AlO9yxYixflH9Spfj/fsS+mD/ANWz/hj8yt+xH+jZ/wANb/8AQ5YsQZ/yS++zCh+Yl9+x2jvUb/xWfmKStef/AC/+1YsXDj6je+CvOvMIdi9WpzP5QsWLT/1FdxeweueZ9qurN8+K2sRZfWVHgV2xmOntVb2jzbyHuWLEzD6ip8A9i/639B9gV7R15O96xYsub1/fyaMfpOZretU/EfanNk5Dkf8AqWLEzN6RUOTgT67/AMTvzFQqLFi9VD0I48uS87P6/h/62IlvyH4x+VYsXMz/AI/0Rsj+GJ2rMcx7lb2fMrFiDJwRclkfVC2FixZe43sUlqzek2ZLFi14hMx/ZWZ5e4oVuz6H8zlixU/Wyo8CyxYsVlH/2Q=="
                        alt=""
                      />
                    </Menu.Button>
                  </div>
                  <Transition
                    as={Fragment}
                    enter="transition ease-out duration-100"
                    enterFrom="transform opacity-0 scale-95"
                    enterTo="transform opacity-100 scale-100"
                    leave="transition ease-in duration-75"
                    leaveFrom="transform opacity-100 scale-100"
                    leaveTo="transform opacity-0 scale-95"
                  >
                    <Menu.Items className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                      <Menu.Item>
                        {({ active }) => (
                          <a
                            href="#"
                            className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                          >
                            Your Profile
                          </a>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <a
                            href="#"
                            className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                          >
                            Settings
                          </a>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <a
                            href="#"
                            className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                          >
                            Sign out
                          </a>
                        )}
                      </Menu.Item>
                    </Menu.Items>
                  </Transition>
                </Menu>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="sm:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2">
              {navigation.map((item) => (
                <Disclosure.Button
                  key={item.name}
                  as="a"
                  href={item.href}
                  className={classNames(
                    item.current ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white',
                    'block rounded-md px-3 py-2 text-base font-medium'
                  )}
                  aria-current={item.current ? 'page' : undefined}
                >
                  {item.name}
                </Disclosure.Button>
              ))}
            </div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  )
}
