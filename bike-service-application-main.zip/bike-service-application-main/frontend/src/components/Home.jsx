import React from 'react';
import { Link } from "react-router-dom";
import NavBar from "./NavBar";

const Home = () => {
  return (
    <>
      <NavBar />
      <div className="flex flex-col items-center text-center min-h-screen bg-white">
        <h1 className="text-3xl font-bold text-slate-000 mb-6 mt-10">Welcome To Our Bike Service Center</h1>
        <div className="flex flex-col md:flex-row items-center p-5 w-full max-w-screen-lg mx-auto">
          <div className="text-slate-600 shadow-xl p-10 rounded-xl text-xl w-full md:w-1/2 flex flex-col mb-8 md:mb-0 md:mr-4">
            <p>Welcome to our bike service center! We're here to ensure that your two-wheeled companion receives the care and attention it deserves. Whether you're in need of a routine check-up, repairs, or a complete overhaul, our team of experienced technicians is ready to provide top-notch service.</p>
            <Link to='/Firststep' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-8">Service Registration</Link>
          </div>
          <div className="bg-white p-6 rounded-lg w-full md:w-1/2 md:ml-4 flex flex-col md:flex-row">
            <div className="mt-8 md:w-w-full md:mr-4">
              <div className="max-w-xs bg-white shadow-lg rounded-lg overflow-hidden">
                <div className="w-full bg-cover" style={{backgroundImage: 'url(https://5.imimg.com/data5/SELLER/Default/2022/12/GI/ZM/XK/20928995/two-wheeler-repairing-service-250x250.jpg)', height: '200px'}}></div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">General service</h3>
                  <p className="text-sm text-gray-700 mb-2">Professional repairing service for your two-wheeler.</p>
                  <div className="flex items-center justify-between">
                    <p className="text-gray-800 font-bold">Price: Rs 500</p>
                    <Link to='/Firststep' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-2 block">Service Registration</Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 md:w-full md:mr-4">
              <div className="max-w-xs bg-white shadow-lg rounded-lg overflow-hidden">
                <div className="w-full bg-cover" style={{backgroundImage: 'url(https://5.imimg.com/data5/SELLER/Default/2022/12/GI/ZM/XK/20928995/two-wheeler-repairing-service-250x250.jpg)', height: '200px'}}></div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">Oil Change</h3>
                  <p className="text-sm text-gray-700 mb-2">Engine Oil change is changed with best cost</p>
                  <div className="flex items-center justify-between">
                    <p className="text-gray-800 font-bold">Price: Rs 250</p>
                    <Link to='/Firststep' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-2 block">Service Registration</Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 md:w-w-full">
              <div className="max-w-xs bg-white shadow-lg rounded-lg overflow-hidden">
                <div className="w-full bg-cover" style={{backgroundImage: 'url(https://5.imimg.com/data5/SELLER/Default/2022/12/GI/ZM/XK/20928995/two-wheeler-repairing-service-250x250.jpg)', height: '200px'}}></div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">Water Wash</h3>
                  <p className="text-sm text-gray-700 mb-2">Professional repairing service for your two-wheeler.</p>
                  <div className="flex items-center justify-between">
                    <p className="text-gray-800 font-bold">Price: Rs 150</p>
                    <Link to='/Firststep' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-2 block">Service Registration</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-center w-full max-w-screen-lg mx-auto">
          <Link to='/Firststep' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-8 md:mr-4">Service Registration</Link>
          <Link to='/States' className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mt-4">Service Table</Link>
        </div>
      </div>
    </>
  );
};

export default Home;
